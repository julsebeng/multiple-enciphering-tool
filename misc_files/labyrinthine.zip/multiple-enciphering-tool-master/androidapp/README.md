This folder contains the android app for the group project.

##Break down of the contents:

###.idea - Configurations and settings (should not need to edit this)

###app - contains most of the source code and the manifest file (important)

###gradle/wrapper - gradle is the build system used by android. Don't edit anything here.

###.gitignore - self-explanatory

### everything else - just more gradle stuff. Android studio edits these for you. Don't edit them yourself.
