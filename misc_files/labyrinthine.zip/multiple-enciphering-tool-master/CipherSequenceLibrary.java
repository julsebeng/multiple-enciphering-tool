import java.util.Vector;

class CipherSequenceLibrary {
	private Vector<String> fileNames;
	private String directoryPath;
	CipherSequenceLibrary(String directory) {
		directoryPath = directory;
	}
	// copy constructor
	CipherSequenceLibrary(CipherSequenceLibrary other) {
	}
	// fetch list of files in Library diectory
	/*
	String[] listFiles() {
	}
	*/
}
